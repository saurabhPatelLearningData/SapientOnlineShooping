package com.saurabhpatel.onlineshopping.dao;

import java.util.List;

import com.saurabhpatel.onlineshopping.entity.Brand;
import com.saurabhpatel.onlineshopping.entity.Product;
import com.saurabhpatel.onlineshopping.entity.SupplierDetails;

public interface ProductRepositoryCustom {

		  List<Product> findAllProductByColor(String name);
		  
		  List<Product> findAllProductByPrice(Double price);
		  
		  List<Product> findAllProductByBrand(String brand);
		  
		  List<Product> findAllProductBySize(String size);
		  
		  List<Product> findAllProductBySKU(String sku);
		  
		  List<Product> findAllProductBySeller(String seller);
		  
		  void saveSellerDetails(SupplierDetails supplierDetails);
		  
		  void saveBrandDetails(Brand brand);
}
