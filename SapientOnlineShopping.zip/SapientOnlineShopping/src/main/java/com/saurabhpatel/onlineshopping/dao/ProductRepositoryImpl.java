package com.saurabhpatel.onlineshopping.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.saurabhpatel.onlineshopping.entity.Brand;
import com.saurabhpatel.onlineshopping.entity.Product;
import com.saurabhpatel.onlineshopping.entity.SupplierDetails;

@Repository
@Transactional
public class ProductRepositoryImpl implements ProductRepositoryCustom{

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public List<Product> findAllProductByColor(String name) {
   
		String querySql ="Select pd " + 
				"from Product pd\r\n" + 
				"inner join pd.brand \r\n" + 
				"inner join pd.color\r\n" + 
				"inner join pd.productCategory\r\n" + 
				"inner join pd.productSize\r\n" + 
				"inner join pd.supplierId\r\n" + 
				"where pd.color.name= :name";

		Query query = entityManager.createQuery(querySql);
		query.setParameter("name", name);
		
		return query.getResultList();
	}

	@Override
	public List<Product> findAllProductByPrice(Double price) {
		String querySql ="Select pd " + 
				"from Product pd\r\n" + 
				"inner join pd.brand \r\n" + 
				"inner join pd.color\r\n" + 
				"inner join pd.productCategory\r\n" + 
				"inner join pd.productSize\r\n" + 
				"inner join pd.supplierId\r\n" + 
				"where pd.price<= :price";

		Query query = entityManager.createQuery(querySql);
		query.setParameter("price", price);
		
		
		return query.getResultList();
	}
	
	@Override
	public List<Product> findAllProductByBrand(String brand) {
		String querySql ="Select pd " + 
				"from Product pd\r\n" + 
				"inner join pd.brand \r\n" + 
				"inner join pd.color\r\n" + 
				"inner join pd.productCategory\r\n" + 
				"inner join pd.productSize\r\n" + 
				"inner join pd.supplierId\r\n" + 
				"where pd.brand.name= :brand";

		Query query = entityManager.createQuery(querySql);
		query.setParameter("brand", brand);
		
		
		return query.getResultList();
	}
	
	@Override
	public List<Product> findAllProductBySize(String size) {
		String querySql ="Select pd " + 
				"from Product pd\r\n" + 
				"inner join pd.brand \r\n" + 
				"inner join pd.color\r\n" + 
				"inner join pd.productCategory\r\n" + 
				"inner join pd.productSize\r\n" + 
				"inner join pd.supplierId\r\n" + 
				"where pd.productSize.name= :size";

		Query query = entityManager.createQuery(querySql);
		query.setParameter("size", size);
		
		
		return query.getResultList();
	}
	
	@Override
	public List<Product> findAllProductBySKU(String sku) {
		String querySql ="Select pd " + 
				"from Product pd\r\n" + 
				"inner join pd.brand \r\n" + 
				"inner join pd.color\r\n" + 
				"inner join pd.productCategory\r\n" + 
				"inner join pd.productSize\r\n" + 
				"inner join pd.supplierId\r\n" + 
				"where pd.productSKU= :sku";

		Query query = entityManager.createQuery(querySql);
		query.setParameter("sku", sku);
		
		
		return query.getResultList();
	}
	
	@Override
	public List<Product> findAllProductBySeller(String seller) {
		String querySql ="Select pd " + 
				"from Product pd\r\n" + 
				"inner join pd.brand \r\n" + 
				"inner join pd.color\r\n" + 
				"inner join pd.productCategory\r\n" + 
				"inner join pd.productSize\r\n" + 
				"inner join pd.supplierId\r\n" + 
				"where pd.supplierId.name= :seller";

		Query query = entityManager.createQuery(querySql);
		query.setParameter("seller", seller);
		
		
		return query.getResultList();
	}

	@Override
	public void saveSellerDetails(SupplierDetails supplierDetails) {
		
		entityManager.persist(supplierDetails);
	}

	@Override
	public void saveBrandDetails(Brand brand) {
		entityManager.persist(brand);
	}

}
