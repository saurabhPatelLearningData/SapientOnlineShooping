package com.saurabhpatel.onlineshopping.represantation;

import com.saurabhpatel.onlineshopping.entity.Color;

public class ColorBO {

	private int id;

	private String name;

	private String description;

	private boolean isActive;

	public ColorBO() {

	}

	public ColorBO(int id, String name, String description, boolean isActive) {
		super();
		this.id = id;
		this.name = name;
		this.description = description;
		this.isActive = isActive;
	}

	public ColorBO(Color color) {
		this.id = color.getId();
		this.name = color.getName();
		this.description = color.getDescription();
		this.isActive = color.isActive();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	@Override
	public String toString() {
		return "ColorBO [id=" + id + ", name=" + name + ", description=" + description + ", isActive=" + isActive + "]";
	}

}
