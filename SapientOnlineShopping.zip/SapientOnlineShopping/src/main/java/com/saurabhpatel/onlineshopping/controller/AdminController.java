package com.saurabhpatel.onlineshopping.controller;

import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.saurabhpatel.onlineshopping.dao.ProductRepository;
import com.saurabhpatel.onlineshopping.entity.Brand;
import com.saurabhpatel.onlineshopping.entity.Product;
import com.saurabhpatel.onlineshopping.entity.SupplierDetails;
import com.saurabhpatel.onlineshopping.represantation.ProductBO;

@RestController
public class AdminController {

	@Autowired
	private ProductRepository productRepository;

	@GetMapping("/products/groupBy/color/{color}")
	public List<ProductBO> findProductByColor(@PathVariable(value = "color") String colorName) {

		List<ProductBO> productBOs = new LinkedList<>();
		for (Product product : productRepository.findAllProductByColor(colorName)) {
			productBOs.add(new ProductBO(product));
		}

		return productBOs;
	}

	@GetMapping("/products/groupBy/price/{price}")
	public List<ProductBO> findProductByPrice(@PathVariable(value = "price") Double price) {

		List<ProductBO> productBOs = new LinkedList<>();
		for (Product product : productRepository.findAllProductByPrice(price)) {
			productBOs.add(new ProductBO(product));
		}

		return productBOs;
	}

	@GetMapping("/products/groupBy/brand/{brand}")
	public List<ProductBO> findProductByPrice(@PathVariable(value = "brand") String brand) {

		List<ProductBO> productBOs = new LinkedList<>();
		for (Product product : productRepository.findAllProductByBrand(brand)) {
			productBOs.add(new ProductBO(product));
		}

		return productBOs;
	}

	@GetMapping("/products/groupBy/size/{size}")
	public List<ProductBO> findProductBySize(@PathVariable(value = "size") String size) {

		List<ProductBO> productBOs = new LinkedList<>();
		for (Product product : productRepository.findAllProductBySize(size)) {
			productBOs.add(new ProductBO(product));
		}

		return productBOs;
	}

	@GetMapping("/products/groupBy/sku/{sku}")
	public List<ProductBO> findProductBySKU(@PathVariable(value = "sku") String sku) {

		List<ProductBO> productBOs = new LinkedList<>();
		for (Product product : productRepository.findAllProductBySKU(sku)) {
			productBOs.add(new ProductBO(product));
		}

		return productBOs;
	}

	@GetMapping("/products/groupBy/seller/{seller}")
	public List<ProductBO> findProductBySeller(@PathVariable(value = "seller") String seller) {

		List<ProductBO> productBOs = new LinkedList<>();
		for (Product product : productRepository.findAllProductBySeller(seller)) {
			productBOs.add(new ProductBO(product));
		}

		return productBOs;
	}
	
	@PostMapping("/add/suppliers")
	public ResponseEntity < SupplierDetails > saveSellerDetails(@RequestBody SupplierDetails supplierDetails) {

		productRepository.saveSellerDetails(supplierDetails);

		return new ResponseEntity < SupplierDetails > (supplierDetails, HttpStatus.OK);
	}
	
	@PostMapping("/add/brand")
	public ResponseEntity < Brand > saveBrandDetails(@RequestBody Brand brand) {

		productRepository.saveBrandDetails(brand);

		return new ResponseEntity < Brand > (brand, HttpStatus.OK);
	}

	@GetMapping("/products/{id}")
	public Product findProductById(@PathVariable(value = "id") int id) {

		Product product = productRepository.findById(id).orElse(null);

		return product;
	}
}
