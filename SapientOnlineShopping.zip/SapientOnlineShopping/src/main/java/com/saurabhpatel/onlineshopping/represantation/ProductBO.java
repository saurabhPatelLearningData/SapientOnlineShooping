package com.saurabhpatel.onlineshopping.represantation;

import com.saurabhpatel.onlineshopping.entity.Product;

public class ProductBO {

	private int id;

	private String productSKU;

	private BrandBO brand;

	private double price;

	private int quantity;

	private boolean isActive;

	private ProductCategoryBO productCategory;

	private SupplierDetailsBO supplierId;

	private int purchases;

	private ColorBO color;

	private ProductSizeBO productSize;

	public ProductBO() {

	}
	
	public ProductBO(int id, String productSKU, BrandBO brand, double price, int quantity, boolean isActive,
			ProductCategoryBO productCategory, SupplierDetailsBO supplierId, int purchases, ColorBO color,
			ProductSizeBO productSize) {
		super();
		this.id = id;
		this.productSKU = productSKU;
		this.brand = brand;
		this.price = price;
		this.quantity = quantity;
		this.isActive = isActive;
		this.productCategory = productCategory;
		this.supplierId = supplierId;
		this.purchases = purchases;
		this.color = color;
		this.productSize = productSize;
	}

	public ProductBO(Product product) {
		this.id = product.getId();
		this.productSKU = product.getProductSKU();
		this.brand = new BrandBO(product.getBrand());
		this.price = product.getPrice();
		this.quantity = product.getQuantity();
		this.isActive = product.isActive();
		this.productCategory = new ProductCategoryBO(product.getCategoryId());
		this.supplierId = new SupplierDetailsBO(product.getSupplierId());
		this.purchases = product.getPurchases();
		this.color = new ColorBO(product.getColor());
		this.productSize = new ProductSizeBO(product.getProductSize());
	}
	

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getProductSKU() {
		return productSKU;
	}

	public void setProductSKU(String productSKU) {
		this.productSKU = productSKU;
	}

	public BrandBO getBrandBO() {
		return brand;
	}

	public void setBrandBO(BrandBO brand) {
		this.brand = brand;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	public ProductCategoryBO getCategoryId() {
		return productCategory;
	}

	public void setCategoryId(ProductCategoryBO productCategory) {
		this.productCategory = productCategory;
	}

	public SupplierDetailsBO getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(SupplierDetailsBO supplierId) {
		this.supplierId = supplierId;
	}

	public int getPurchases() {
		return purchases;
	}

	public void setPurchases(int purchases) {
		this.purchases = purchases;
	}

	public ColorBO getColor() {
		return color;
	}

	public void setColor(ColorBO color) {
		this.color = color;
	}

	public ProductSizeBO getProductSize() {
		return productSize;
	}

	public void setProductSize(ProductSizeBO productSize) {
		this.productSize = productSize;
	}

	@Override
	public String toString() {
		return "ProductBO [id=" + id + ", productSKU=" + productSKU + ", brand=" + brand + ", price=" + price
				+ ", quantity=" + quantity + ", isActive=" + isActive + ", productCategory=" + productCategory
				+ ", supplierId=" + supplierId + ", purchases=" + purchases + ", color=" + color + ", productSize="
				+ productSize + "]";
	}

}
